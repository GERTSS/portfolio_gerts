CREATE DATABASE skillbox_db;
